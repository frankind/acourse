// const angular = require('angular')
import angular from 'angular'

import 'angular-ui-router'
import './app.module'
import './app.controller'
import './app.config'
import './detail.controller'
angular.bootstrap(document, ['app'])
