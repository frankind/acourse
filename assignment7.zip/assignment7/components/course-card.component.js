export default {
  selector: 'courseCard',
  template: require('./course-card.component.html'),
  bindings: {
    course: '<'
  }
}
